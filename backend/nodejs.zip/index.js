const connectToMongo = require('./db');
const express = require('express')
var cors = require('cors');
const fileUpload = require('express-fileupload');

connectToMongo();

const app = express()
const port = 5000

app.use(cors())
app.use(express.json())

// app.use(express.static('public'))
app.use(fileUpload());
// Available Routes
// app.use('/api/auth', require('./routes/auth'))
app.use('/api/clips', require('./routes/clips'))

app.get('/', (req, res) => {
  res.send('Hello Ronak!')
})

app.listen(port, () => {
  console.log(`iClip listening at http://localhost:${port}`)
})